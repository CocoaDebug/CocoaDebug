//
//  Example
//  man
//
//  Created by man on 11/11/2018.
//  Copyright © 2018 man. All rights reserved.
//

#import "_WHDebugMonitor.h"

@interface _WHDebugCpuMonitor : _WHDebugMonitor

@end
