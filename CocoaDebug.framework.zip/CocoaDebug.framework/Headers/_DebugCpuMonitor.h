////
////  Example
////  man.li
////
////  Created by man.li on 11/11/2018.
////  Copyright © 2020 man.li. All rights reserved.
////
//
//#import "CocoaDebug.h"
//
//@interface _DebugCpuMonitor : _DebugMonitor
//
//+ (instancetype)sharedInstance;
//
//@end
