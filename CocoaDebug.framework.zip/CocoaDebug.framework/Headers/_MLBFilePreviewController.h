//
//  Example
//  man.li
//
//  Created by man.li on 11/11/2018.
//  Copyright © 2020 man.li. All rights reserved.
//

#import <UIKit/UIKit.h>

@class _MLBFileInfo;

@interface _MLBFilePreviewController : UIViewController

@property (nonatomic, strong) _MLBFileInfo *fileInfo;

@end
