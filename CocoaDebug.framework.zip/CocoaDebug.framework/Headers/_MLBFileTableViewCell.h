//
//  Example
//  man
//
//  Created by man on 11/11/2018.
//  Copyright © 2018 man. All rights reserved.
//

#import <UIKit/UIKit.h>

UIKIT_EXTERN NSString *const _MLBFileTableViewCellReuseIdentifier;

@interface _MLBFileTableViewCell : UITableViewCell

@end
